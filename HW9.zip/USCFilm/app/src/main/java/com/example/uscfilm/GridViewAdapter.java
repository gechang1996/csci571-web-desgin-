package com.example.uscfilm;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// The adapter class which
// extends RecyclerView Adapter
public class GridViewAdapter
        extends RecyclerView.Adapter<GridViewAdapter.MyView>
        implements ItemMoveCallback.ItemTouchHelperContract{

    //JSON ARRAY
    private JSONArray jsonArray;
    private View itemView;

    // View Holder class which
    // extends RecyclerView.ViewHolder
    public class MyView
            extends RecyclerView.ViewHolder {

        // Image View
        ImageView imageview;
        //TextView
        TextView type;

        ImageView remove_button;

        // parameterised constructor for View Holder class
        // which takes the view as a parameter
        public MyView(View view)
        {
            super(view);


            imageview = (ImageView)view.findViewById(R.id.imageview_card);

            type=view.findViewById(R.id.type_watchlist_card);
            remove_button=view.findViewById(R.id.watchlist_remove);
        }
    }

    // Constructor for adapter class
    // which takes a list of String type
    public GridViewAdapter(JSONArray jsonArray)
    {
        this.jsonArray=jsonArray;
    }

    // Override onCreateViewHolder which deals
    // with the inflation of the card layout
    // as an item for the RecyclerView.
    @NonNull
    @Override
    public MyView onCreateViewHolder(ViewGroup parent,
                                     int viewType)
    {

        // Inflate item.xml using LayoutInflator
        itemView
                = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.watchlist_item,
                        parent,
                        false);

        // return itemView
        return new MyView(itemView);
    }

    // Override onBindViewHolder which deals
    // with the setting of different data
    // and methods related to clicks on
    // particular items of the RecyclerView.
    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(final MyView holder,
                                 final int position)
    {

        // Set the text of each item of
        // Recycler view with the list items

        try {
            JSONObject tmp_obj=jsonArray.getJSONObject(position);
            Glide.with(holder.itemView)
                    .load(tmp_obj.getString("poster_path"))
                    .fitCenter()
                    .into(holder.imageview);
            holder.type.setText(tmp_obj.getString("media_type").toUpperCase());


        } catch (JSONException e) {
            e.printStackTrace();
        }

        holder.imageview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent myIntent = new Intent(holder.itemView.getContext(), detailActivity.class);
                    myIntent.putExtra("media_type", jsonArray.getJSONObject(position).getString("media_type"));
                    myIntent.putExtra("id", jsonArray.getJSONObject(position).getInt("id"));
                    holder.itemView.getContext().startActivity(myIntent);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
//                AppCompatActivity activity = (AppCompatActivity) v.getContext();
//                Fragment myFragment = new SearchFragment();
//                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, myFragment).addToBackStack(null).commit();

            }
        });

        holder.remove_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences pref = v.getContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
                SharedPreferences.Editor editor = pref.edit();
                try {
                    JSONObject tmp_obj=jsonArray.getJSONObject(position);
                    String name=tmp_obj.getString("name");
                    Toast.makeText(v.getContext(), name+ " was removed from the Watchlist", Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }


                jsonArray.remove(position);
                editor.putString("watchlist", jsonArray.toString()); // Storing string
                editor.apply();


                AppCompatActivity activity = (AppCompatActivity) v.getContext();
                Fragment myFragment = new WatchlistFragment();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, myFragment).addToBackStack(null).commit();

            }
        });


    }

    // Override getItemCount which Returns
    // the length of the RecyclerView.
    @Override
    public int getItemCount()
    {
        return jsonArray.length();
    }

    @Override
    public void onRowMoved(int fromPosition, int toPosition) throws JSONException {
        ArrayList<JSONObject> listdata = new ArrayList<JSONObject>();

        if (jsonArray != null) {
            for (int i=0;i<jsonArray.length();i++){
                listdata.add(jsonArray.getJSONObject(i));
            }
        }
        if (fromPosition < toPosition) {
            for (int i = fromPosition; i < toPosition; i++) {
                Collections.swap(listdata, i, i + 1);
            }
        } else {
            for (int i = fromPosition; i > toPosition; i--) {
                Collections.swap(listdata, i, i - 1);
            }
        }
        jsonArray= new JSONArray(listdata);

        SharedPreferences pref =itemView.getContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("watchlist", jsonArray.toString()); // Storing string
        editor.apply();
        notifyItemMoved(fromPosition, toPosition);
    }

    @Override
    public void onRowSelected(MyView myViewHolder) {
        myViewHolder.itemView.setBackgroundColor(Color.GRAY);

    }

    @Override
    public void onRowClear(MyView myViewHolder) {
        myViewHolder.itemView.setBackgroundColor(Color.WHITE);

    }

}