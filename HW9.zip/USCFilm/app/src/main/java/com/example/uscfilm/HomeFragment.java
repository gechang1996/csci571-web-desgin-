package com.example.uscfilm;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.smarteist.autoimageslider.SliderView;

import android.util.Log;
import android.widget.TextView;
import android.widget.ScrollView;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.view.View.OnClickListener;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class HomeFragment extends Fragment{


    private RequestQueue requestQueue;
    private TextView textView_loading;
    private ProgressBar pgsBar;
    private TextView home_title;
    private TextView movie_button;
    private TextView TVShow_button;
    private NestedScrollView home_scroll;
    private JSONArray current_playing_movie;
    private JSONArray current_playing_TV;
    private JSONArray top_rated_movie;
    private JSONArray top_rated_TV;
    private  JSONArray PopularMovie;
    private  JSONArray PopularTVShows;
    private TextView TMDB_footer;
    // Recycler View object
    private RecyclerView recyclerView;

    // Layout Manager
    private RecyclerView.LayoutManager RecyclerViewLayoutManager;

    // adapter class object
    private RecyclerViewAdapter adapter;

    // Linear Layout Manager
    private LinearLayoutManager HorizontalLayout;
    private View v;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v=inflater.inflate(R.layout.fragment_home,container,false);
        requestQueue = Volley.newRequestQueue(v.getContext());
        pgsBar = (ProgressBar) v.findViewById(R.id.pBar_home);
        textView_loading=v.findViewById(R.id.loadingText_home);
        movie_button=v.findViewById(R.id.home_movie_button);
        TVShow_button=v.findViewById(R.id.home_TV_button);
        home_title=v.findViewById(R.id.home_title);
        home_scroll=v.findViewById(R.id.home_vertical_scrollView);
        TMDB_footer=v.findViewById(R.id.footer_tmdb);

        click_footer();
        click_movie();
        click_TV();
        jsonParse(v);




        return v;
    }

    private void init_topRated(JSONArray top_rated){
        // initialisation with id's
        recyclerView
                = (RecyclerView)v.findViewById(
                R.id.recyclerview_topRated);
        RecyclerViewLayoutManager
                = new LinearLayoutManager(
                v.getContext());

        // Set LayoutManager on Recycler View
        recyclerView.setLayoutManager(
                RecyclerViewLayoutManager);



        // calling constructor of adapter
        // with source list as a parameter
        adapter = new RecyclerViewAdapter(top_rated);

        // Set Horizontal Layout Manager
        // for Recycler view
        HorizontalLayout
                = new LinearLayoutManager(
                v.getContext(),
                LinearLayoutManager.HORIZONTAL,
                false);
        recyclerView.setLayoutManager(HorizontalLayout);

        // Set adapter on recycler view
        recyclerView.setAdapter(adapter);

    }


    private void init_popular(JSONArray popular){
        // initialisation with id's
        recyclerView
                = (RecyclerView)v.findViewById(
                R.id.recyclerview_popular);
        RecyclerViewLayoutManager
                = new LinearLayoutManager(
                v.getContext());

        // Set LayoutManager on Recycler View
        recyclerView.setLayoutManager(
                RecyclerViewLayoutManager);



        // calling constructor of adapter
        // with source list as a parameter
        adapter = new RecyclerViewAdapter(popular);

        // Set Horizontal Layout Manager
        // for Recycler view
        HorizontalLayout
                = new LinearLayoutManager(
                v.getContext(),
                LinearLayoutManager.HORIZONTAL,
                false);
        recyclerView.setLayoutManager(HorizontalLayout);

        // Set adapter on recycler view
        recyclerView.setAdapter(adapter);

    }

    private void jsonParse(View v) {
        //popular tv
        String url = "https://changge-csci571-hw9-backend.wm.r.appspot.com/PopularTVShows";
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                PopularTVShows=response;
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        //current movie
        url="https://changge-csci571-hw9-backend.wm.r.appspot.com/CurrentPlayingMovies";
        JsonArrayRequest request2 = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                current_playing_movie=response;
                try {
                    initial_current(current_playing_movie);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        //current tv
        url="https://changge-csci571-hw9-backend.wm.r.appspot.com/TrendingTVShows";
        JsonArrayRequest request3 = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                current_playing_TV=response;
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        //top-rated movie
        url="https://changge-csci571-hw9-backend.wm.r.appspot.com/Top-RatedMovies";
        JsonArrayRequest request4 = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                top_rated_movie=response;
                init_topRated(top_rated_movie);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        //top-rated tv
        url="https://changge-csci571-hw9-backend.wm.r.appspot.com/Top-RatedTVShows";
        JsonArrayRequest request5 = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                top_rated_TV=response;
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        //popular movie
        url="https://changge-csci571-hw9-backend.wm.r.appspot.com/PopularMovies";
        JsonArrayRequest request6 = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                PopularMovie=response;
                init_popular(PopularMovie);
                //init the home screen
                pgsBar.setVisibility(View.GONE);
                textView_loading.setVisibility(View.GONE);
                home_title.setVisibility(View.VISIBLE);
                movie_button.setVisibility(View.VISIBLE);
                TVShow_button.setVisibility(View.VISIBLE);
                home_scroll.setVisibility(View.VISIBLE);


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });


        requestQueue.add(request);
        requestQueue.add(request2);
        requestQueue.add(request3);
        requestQueue.add(request4);
        requestQueue.add(request5);
        requestQueue.add(request6);
    }

    private void click_footer(){
        TMDB_footer.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("https://www.themoviedb.org/");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                v.getContext().startActivity(intent);
            }

        });

    }

    private void click_movie(){
        movie_button.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                movie_button.setTextColor(getResources().getColor(R.color.white));
                TVShow_button.setTextColor(getResources().getColor(R.color.icon_blue));
                    init_popular(PopularMovie);
                    init_topRated(top_rated_movie);

                try {
                    initial_current(current_playing_movie);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        });

    }

    private void click_TV(){
        TVShow_button.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                TVShow_button.setTextColor(getResources().getColor(R.color.white));
                movie_button.setTextColor(getResources().getColor(R.color.icon_blue));
                init_popular(PopularTVShows);
                init_topRated(top_rated_TV);
                try {
                    initial_current(current_playing_TV);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        });

    }

    private void initial_current(JSONArray current_array) throws JSONException {

        // initializing the slider view.
        SliderView sliderView = v.findViewById(R.id.slider);

        JSONObject tmp_obj;

        // passing this array list inside our adapter class.
        SliderAdapter adapter = new SliderAdapter(v.getContext(),current_array);


        // below method is used to set auto cycle direction in left to
        // right direction you can change according to requirement.
        sliderView.setAutoCycleDirection(SliderView.LAYOUT_DIRECTION_LTR);

        // below method is used to
        // setadapter to sliderview.
        sliderView.setSliderAdapter(adapter);


        // below method is use to set
        // scroll time in seconds.
        sliderView.setScrollTimeInSec(3);

        // to set it scrollable automatically
        // we use below method.
        sliderView.setAutoCycle(true);

        // to start autocycle below method is used.
        sliderView.startAutoCycle();

    }



}

