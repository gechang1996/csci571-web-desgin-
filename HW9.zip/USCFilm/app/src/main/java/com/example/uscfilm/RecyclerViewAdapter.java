package com.example.uscfilm;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.widget.PopupMenu;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

// The adapter class which
// extends RecyclerView Adapter
public class RecyclerViewAdapter
        extends RecyclerView.Adapter<RecyclerViewAdapter.MyView> {



    //JSON ARRAY
    private JSONArray jsonArray;

    // View Holder class which
    // extends RecyclerView.ViewHolder
    public class MyView
            extends RecyclerView.ViewHolder {

        // Image View
        ImageView imageview;
        //menu bar
        ImageView menu_bar;
        // parameterised constructor for View Holder class
        // which takes the view as a parameter
        public MyView(View view)
        {
            super(view);

            // initialise TextView with id
            menu_bar=(ImageView)view.findViewById(R.id.home_menu_bar);
            imageview = (ImageView)view.findViewById(R.id.imageview_card);
        }
    }

    // Constructor for adapter class
    // which takes a list of String type
    public RecyclerViewAdapter(JSONArray jsonArray)
    {
        this.jsonArray=jsonArray;
    }

    // Override onCreateViewHolder which deals
    // with the inflation of the card layout
    // as an item for the RecyclerView.
    @NonNull
    @Override
    public MyView onCreateViewHolder(ViewGroup parent,
                                     int viewType)
    {

        // Inflate item.xml using LayoutInflator
        View itemView
                = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.item,
                        parent,
                        false);

        // return itemView
        return new MyView(itemView);
    }

    // Override onBindViewHolder which deals
    // with the setting of different data
    // and methods related to clicks on
    // particular items of the RecyclerView.
    @Override
    public void onBindViewHolder(final MyView holder,
                                 final int position)
    {

        // Set the text of each item of
        // Recycler view with the list items

        try {
            JSONObject tmp_obj=jsonArray.getJSONObject(position);
            Glide.with(holder.itemView)
                    .load(tmp_obj.getString("poster_path"))
                    .fitCenter()
                    .into(holder.imageview);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        holder.imageview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    Intent myIntent = new Intent(holder.itemView.getContext(), detailActivity.class);
                    myIntent.putExtra("media_type", jsonArray.getJSONObject(position).getString("media_type"));
                    myIntent.putExtra("id", jsonArray.getJSONObject(position).getInt("id"));
                    holder.itemView.getContext().startActivity(myIntent);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
//                AppCompatActivity activity = (AppCompatActivity) v.getContext();
//                Fragment myFragment = new SearchFragment();
//                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, myFragment).addToBackStack(null).commit();

            }
        });

        holder.menu_bar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


//                AppCompatActivity activity = (AppCompatActivity) v.getContext();
//                Fragment myFragment = new SearchFragment();
//                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, myFragment).addToBackStack(null).commit();
                // Initializing the popup menu and giving the reference as current context
                PopupMenu popupMenu = new PopupMenu(v.getContext(), holder.menu_bar);
                // Inflating popup menu from popup_menu.xml file
                popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());
                SharedPreferences pref = v.getContext().getSharedPreferences("MyPref", 0); // 0 - for private mode

                JSONArray tmp_array=new JSONArray();
                if (pref.getString("watchlist", null) !=null){
                    try {
                        tmp_array=new JSONArray(pref.getString("watchlist", null));
                        JSONObject tmp_obj=jsonArray.getJSONObject(position);
                        int id=tmp_obj.getInt("id");
                        String media_type=tmp_obj.getString("media_type");
                        boolean found = false;
                        for (int i = 0; i < tmp_array.length(); i++) {
                            if (tmp_array.getJSONObject(i).getInt("id")==id & tmp_array.getJSONObject(i).getString("media_type").equals(media_type)){
                                found=true;
                            }
                        }
                        if (found){
                            popupMenu.getMenu().findItem(R.id.remove_watchlist).setVisible(true);
                            popupMenu.getMenu().findItem(R.id.add_watchlist).setVisible(false);
                        }
                        else{
                            popupMenu.getMenu().findItem(R.id.remove_watchlist).setVisible(false);
                            popupMenu.getMenu().findItem(R.id.add_watchlist).setVisible(true);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else{
                    popupMenu.getMenu().findItem(R.id.remove_watchlist).setVisible(false);
                    popupMenu.getMenu().findItem(R.id.add_watchlist).setVisible(true);

                }


                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @SuppressLint("NonConstantResourceId")
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        // Toast message on menu item clicked
                        try {
                            SharedPreferences pref = v.getContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
                            SharedPreferences.Editor editor = pref.edit();



                            JSONObject tmp_obj=jsonArray.getJSONObject(position);
                            int id=tmp_obj.getInt("id");
                            String name=tmp_obj.getString("name");
                            String media_type=tmp_obj.getString("media_type");
                            String poster_path=tmp_obj.getString("poster_path");
                            Uri uri;
                            JSONArray tmp_array;
                            Intent intent;
                            switch(menuItem.getItemId()){
                                case R.id.open_TMDB:
                                    uri = Uri.parse("https://www.themoviedb.org/"+media_type+"/"+id);
                                    intent = new Intent(Intent.ACTION_VIEW, uri);
                                    v.getContext().startActivity(intent);
                                    break;
                                case R.id.share_fb:
                                    uri = Uri.parse("https://www.facebook.com/sharer/sharer.php?u="+"https://www.themoviedb.org/"+media_type+"/"+id);
                                    intent = new Intent(Intent.ACTION_VIEW, uri);
                                    v.getContext().startActivity(intent);
                                    break;
                                case R.id.share_tw:
                                    uri = Uri.parse("https://twitter.com/intent/tweet?text="+"Check this out!%0D%0A"+"https://www.themoviedb.org/"+media_type+"/"+id);
                                    intent = new Intent(Intent.ACTION_VIEW, uri);
                                    v.getContext().startActivity(intent);
                                    break;
                                case R.id.add_watchlist:
                                    //add local storage
                                    tmp_array=new JSONArray();
                                    if (pref.getString("watchlist", null) !=null){
                                        tmp_array=new JSONArray(pref.getString("watchlist", null));
                                    }
                                    else{
                                        tmp_array=new JSONArray();
                                    }
                                    boolean found = false;
                                    for (int i = 0; i < tmp_array.length(); i++) {
                                        if (tmp_array.getJSONObject(i).getInt("id")==id & tmp_array.getJSONObject(i).getString("media_type").equals(media_type)){
                                            found=true;
                                        }

                                    }

                                    if(!found){
                                        tmp_obj=new JSONObject();
                                        tmp_obj.put("id",id);
                                        tmp_obj.put("media_type",media_type);
                                        tmp_obj.put("poster_path",poster_path);
                                        tmp_obj.put("name",name);
                                        tmp_array.put(tmp_obj);
                                        editor.putString("watchlist", tmp_array.toString()); // Storing string

                                        editor.apply(); // commit changes
                                    }

                                    Log.i("localStorage:",pref.getString("watchlist", null));
                                    Toast.makeText(v.getContext(), name+ " was added to the Watchlist", Toast.LENGTH_SHORT).show();
                                    break;

                                case R.id.remove_watchlist:
                                    tmp_array=new JSONArray(pref.getString("watchlist", null));
                                    int tmp_pos=0;
                                    for (int i = 0; i < tmp_array.length(); i++) {
                                        if (tmp_array.getJSONObject(i).getInt("id")==id & tmp_array.getJSONObject(i).getString("media_type").equals(media_type)){
                                            tmp_pos=i;
                                        }
                                    }
                                    tmp_array.remove(tmp_pos);
                                    editor.putString("watchlist", tmp_array.toString()); // Storing string
                                    editor.apply(); // commit changes
                                    Toast.makeText(v.getContext(), name+ " was removed from the Watchlist", Toast.LENGTH_SHORT).show();
                                    break;
                            }
                            return true;
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    return true;
                    }
                });
                // Showing the popup menu
                popupMenu.show();
            }
        });



    }

    // Override getItemCount which Returns
    // the length of the RecyclerView.
    @Override
    public int getItemCount()
    {
        return jsonArray.length();
    }

}
