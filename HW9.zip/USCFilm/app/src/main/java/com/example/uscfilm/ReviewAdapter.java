package com.example.uscfilm;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// The adapter class which
// extends RecyclerView Adapter
public class ReviewAdapter
        extends RecyclerView.Adapter<ReviewAdapter.MyView>
{

    //JSON ARRAY
    private JSONArray jsonArray;
    private View itemView;


    // View Holder class which
    // extends RecyclerView.ViewHolder
    public class MyView
            extends RecyclerView.ViewHolder {



        //TextView
        TextView review_title;
        TextView rating;
        TextView review_content;
        CardView cardview;


        // parameterised constructor for View Holder class
        // which takes the view as a parameter
        public MyView(View view)
        {
            super(view);


            cardview=view.findViewById(R.id.cardview);

            review_title=view.findViewById(R.id.review_title);
            rating=view.findViewById(R.id.rating);
            review_content=view.findViewById(R.id.review_content);

        }
    }

    // Constructor for adapter class
    // which takes a list of String type
    public ReviewAdapter(JSONArray jsonArray)
    {
        this.jsonArray=jsonArray;
    }

    // Override onCreateViewHolder which deals
    // with the inflation of the card layout
    // as an item for the RecyclerView.
    @NonNull
    @Override
    public MyView onCreateViewHolder(ViewGroup parent,
                                     int viewType)
    {

        // Inflate item.xml using LayoutInflator
        itemView
                = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.review_item,
                        parent,
                        false);

        // return itemView
        return new MyView(itemView);
    }

    // Override onBindViewHolder which deals
    // with the setting of different data
    // and methods related to clicks on
    // particular items of the RecyclerView.
    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(final MyView holder,
                                 final int position)
    {

        // Set the text of each item of
        // Recycler view with the list items

        try {
            JSONObject tmp_obj=jsonArray.getJSONObject(position);


            holder.review_title.setText("by "+tmp_obj.getString("author")+" on "+tmp_obj.getString("created_at"));
            int cur_rating=tmp_obj.getInt("rating");

            holder.rating.setText((int)(cur_rating/2)+ "/5");

            holder.review_content.setText(tmp_obj.getString("content"));

            holder.cardview.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    try {
                        JSONObject tmp_obj=jsonArray.getJSONObject(position);
                        Intent myIntent = new Intent(holder.itemView.getContext(), ReviewsActivity.class);
                        myIntent.putExtra("review_title", "by "+tmp_obj.getString("author")+" on "+tmp_obj.getString("created_at"));
                        myIntent.putExtra("rating", (int)(cur_rating/2)+ "/5");
                        myIntent.putExtra("review_content", tmp_obj.getString("content"));
                        holder.itemView.getContext().startActivity(myIntent);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });



        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    // Override getItemCount which Returns
    // the length of the RecyclerView.
    @Override
    public int getItemCount()
    {
        return jsonArray.length();
    }
}