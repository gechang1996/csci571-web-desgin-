package com.example.uscfilm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class ReviewsActivity extends AppCompatActivity {
    private String review_title;
    private String rating;
    private String review_content;
    private TextView review_title_TextView;
    private TextView rating_TextView;
    private TextView review_content_TextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reviews);

        review_title = getIntent().getStringExtra("review_title");
        rating = getIntent().getStringExtra("rating");
        review_content = getIntent().getStringExtra("review_content");

        review_title_TextView=findViewById(R.id.review_title);
        rating_TextView=findViewById(R.id.rating);
        review_content_TextView=findViewById(R.id.review_content);
        review_title_TextView.setText(review_title);
        rating_TextView.setText(rating);
        review_content_TextView.setText(review_content);




    }
}