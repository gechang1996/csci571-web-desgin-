package com.example.uscfilm;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.SearchView;

import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.w3c.dom.Text;


public class SearchFragment extends Fragment{
    private SearchView searchView;
    private EditText searchEditText;
    private RequestQueue requestQueue;
    private View v;
    private JSONArray search_result;
//    private Handler handler = new Handler();
    private TextView noResult;
    private NestedScrollView scrollView;
    // Recycler View object
    private RecyclerView recyclerView;
    // Layout Manager
    private RecyclerView.LayoutManager RecyclerViewLayoutManager;
    // adapter class object
    private RecyclerViewAdapterSearch adapter;
    // Linear Layout Manager
    private LinearLayoutManager VerticalLayout;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v=inflater.inflate(R.layout.fragment_search,container,false);
        searchView=(SearchView) v.findViewById(R.id.search_view);
        searchEditText=searchView.findViewById(androidx.appcompat.R.id.search_src_text);
        searchEditText.setTextColor(getResources().getColor(R.color.light_grey));
        searchEditText.setHintTextColor(getResources().getColor(R.color.light_grey));
        requestQueue = Volley.newRequestQueue(v.getContext());
        noResult=v.findViewById(R.id.noResult);
        scrollView=v.findViewById(R.id.search_vertical_scrollView);

        Init_Search();
        return v;
    }


    private void updateResult(JSONArray search_array){
        // initialisation with id's
        recyclerView
                = (RecyclerView)v.findViewById(
                R.id.search_result);
        RecyclerViewLayoutManager
                = new LinearLayoutManager(
                v.getContext());

        // Set LayoutManager on Recycler View
        recyclerView.setLayoutManager(
                RecyclerViewLayoutManager);


        // calling constructor of adapter
        // with source list as a parameter
        adapter = new RecyclerViewAdapterSearch(search_array);

        // Set Horizontal Layout Manager
        // for Recycler view
        VerticalLayout
                = new LinearLayoutManager(
                v.getContext(),
                LinearLayoutManager.VERTICAL,
                false);
        recyclerView.setLayoutManager(VerticalLayout);

        // Set adapter on recycler view
        recyclerView.setAdapter(adapter);

    }


    private void jsonParse(String keywrod) {
        //popular tv
        String url = "https://changge-csci571-hw9-backend.wm.r.appspot.com/search?keyword="+keywrod;

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                search_result = response;
                if (response.length()==0){
                    noResult.setVisibility(View.VISIBLE);
                    scrollView.setVisibility(View.GONE);
                }
                else{
                    updateResult(response);
                    noResult.setVisibility(View.GONE);
                    scrollView.setVisibility(View.VISIBLE);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        requestQueue.add(request);
    }


    public void Init_Search(){


        searchView.setMaxWidth(Integer.MAX_VALUE);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {


//                // Cancel any previous place prediction requests
//                handler.removeCallbacksAndMessages(null);

//                // Start a new place prediction request in 300 ms
//                handler.postDelayed(() -> {
//                        jsonParse(newText);
//                }, 300);
                jsonParse(newText);
                return true;
            }
        });

    }


}
