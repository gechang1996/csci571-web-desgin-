package com.example.uscfilm;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.android.volley.toolbox.JsonObjectRequest;
import com.bumptech.glide.Glide;
import com.smarteist.autoimageslider.SliderViewAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import jp.wasabeef.glide.transformations.BlurTransformation;

public class SliderAdapter extends SliderViewAdapter<SliderAdapter.SliderAdapterViewHolder> {

    // list for storing urls of images.

    private  JSONArray jsonArray;

    // Constructor
    public SliderAdapter(Context context,JSONArray jsonArray) {

        this.jsonArray=jsonArray;
    }

    // We are inflating the slider_layout
    // inside on Create View Holder method.
    @Override
    public SliderAdapterViewHolder onCreateViewHolder(ViewGroup parent) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.slider_layout, null);
        return new SliderAdapterViewHolder(inflate);
    }


    // Inside on bind view holder we will
    // set data to item of Slider View.
    @Override
    public void onBindViewHolder(SliderAdapterViewHolder viewHolder, final int position) {



        try {
            JSONObject tmp_obj=jsonArray.getJSONObject(position);
            // Glide is use to load image
            // from url in your imageview.
            Glide.with(viewHolder.itemView)
                    .load(tmp_obj.getString("poster_path"))
                    .fitCenter()
                    .transform( new BlurTransformation(25) )
                    .into(viewHolder.imageViewBackground);

            Glide.with(viewHolder.itemView)
                    .load(tmp_obj.getString("poster_path"))
                    .fitCenter()
                    .into(viewHolder.imageViewInside);


        } catch (JSONException e) {
            e.printStackTrace();
        }




        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Click", String.valueOf(position));

                try {
                    Intent myIntent = new Intent(viewHolder.itemView.getContext(), detailActivity.class);
                    myIntent.putExtra("media_type", jsonArray.getJSONObject(position).getString("media_type"));
                    myIntent.putExtra("id", jsonArray.getJSONObject(position).getInt("id"));
                    viewHolder.itemView.getContext().startActivity(myIntent);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

//                AppCompatActivity activity = (AppCompatActivity) v.getContext();
//                Fragment myFragment = new SearchFragment();
//                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, myFragment).addToBackStack(null).commit();

            }
        });



    }

    // this method will return
    // the count of our list.
    @Override
    public int getCount() {
        return jsonArray.length();
    }

    static class SliderAdapterViewHolder extends SliderViewAdapter.ViewHolder {
        // Adapter class for initializing
        // the views of our slider view.
        View itemView;
        ImageView imageViewBackground;
        ImageView imageViewInside;

        public SliderAdapterViewHolder(View itemView) {
            super(itemView);
            imageViewBackground = itemView.findViewById(R.id.myimage);
            imageViewInside=itemView.findViewById(R.id.inside_imageview);
            this.itemView = itemView;

        }
    }
}