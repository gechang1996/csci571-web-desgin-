package com.example.uscfilm;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;

public class WatchlistFragment extends Fragment{
    private View v;
    private JSONArray watchlist;
    private TextView empty_mes;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v= inflater.inflate(R.layout.fragment_watchlist,container,false);
//        empty_mes=v.findViewById(R.id.empty_watchlist);
//        try {
//            showWatchListResult();
//
//
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }


        return v;
    }

    @Override
    public void onResume()
    {  // After a pause OR at startup
        super.onResume();
        empty_mes=v.findViewById(R.id.empty_watchlist);
        try {
            showWatchListResult();


        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void showWatchListResult() throws JSONException {
        SharedPreferences pref = v.getContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
//        SharedPreferences.Editor editor = pref.edit();
        //add local storage
        watchlist=new JSONArray(pref.getString("watchlist", null));
        if (watchlist.length()!=0){
            empty_mes.setVisibility(View.GONE);
            // get the reference of RecyclerView
            RecyclerView recyclerView = (RecyclerView) v.findViewById(R.id.recyclerView);
            // set a GridLayoutManager with default vertical orientation and 3 number of columns
            GridLayoutManager gridLayoutManager = new GridLayoutManager(v.getContext(),3);
            recyclerView.setLayoutManager(gridLayoutManager); // set LayoutManager to RecyclerView
            //  call the constructor of CustomAdapter to send the reference and data to Adapter
            GridViewAdapter customAdapter = new GridViewAdapter(watchlist);
            ItemTouchHelper.Callback callback =
                    new ItemMoveCallback(customAdapter);
            ItemTouchHelper touchHelper = new ItemTouchHelper(callback);
            touchHelper.attachToRecyclerView(recyclerView);

            recyclerView.setAdapter(customAdapter); // set the Adapter to RecyclerView
        }
        else{
            watchlist=new JSONArray();
            empty_mes.setVisibility(View.VISIBLE);
        }







    }
}
