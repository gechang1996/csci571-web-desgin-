package com.example.uscfilm;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// The adapter class which
// extends RecyclerView Adapter
public class castAdapter
        extends RecyclerView.Adapter<castAdapter.MyView>
        {

    //JSON ARRAY
    private JSONArray jsonArray;
    private View itemView;

    // View Holder class which
    // extends RecyclerView.ViewHolder
    public class MyView
            extends RecyclerView.ViewHolder {

        // Image View
        ImageView imageview;
        //TextView
        TextView cast_name;



        // parameterised constructor for View Holder class
        // which takes the view as a parameter
        public MyView(View view)
        {
            super(view);


            imageview = (ImageView)view.findViewById(R.id.imageview_card);
            cast_name=view.findViewById(R.id.cast_name);

        }
    }

    // Constructor for adapter class
    // which takes a list of String type
    public castAdapter(JSONArray jsonArray)
    {
        this.jsonArray=jsonArray;
    }

    // Override onCreateViewHolder which deals
    // with the inflation of the card layout
    // as an item for the RecyclerView.
    @NonNull
    @Override
    public MyView onCreateViewHolder(ViewGroup parent,
                                     int viewType)
    {

        // Inflate item.xml using LayoutInflator
        itemView
                = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.cast_item,
                        parent,
                        false);

        // return itemView
        return new MyView(itemView);
    }

    // Override onBindViewHolder which deals
    // with the setting of different data
    // and methods related to clicks on
    // particular items of the RecyclerView.
    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(final MyView holder,
                                 final int position)
    {

        // Set the text of each item of
        // Recycler view with the list items

        try {
            JSONObject tmp_obj=jsonArray.getJSONObject(position);
            Glide.with(holder.itemView)
                    .load(tmp_obj.getString("profile_path"))
                    .fitCenter()
                    .into(holder.imageview);

            holder.cast_name.setText(tmp_obj.getString("name"));


        } catch (JSONException e) {
            e.printStackTrace();
        }





    }

    // Override getItemCount which Returns
    // the length of the RecyclerView.
    @Override
    public int getItemCount()
    {
        return jsonArray.length();
    }
}