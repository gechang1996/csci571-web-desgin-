package com.example.uscfilm;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;
import com.smarteist.autoimageslider.SliderView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.net.URI;

public class detailActivity extends Activity {
    private String media_type;
    private int id;
    private boolean found=false;
    private NestedScrollView home_vertical_scrollView;
    private String name;
    private String poster_path;
    private JSONArray detail_array;
    private JSONArray video_array;
    private JSONArray cast_array;
    private JSONArray review_array;
    private JSONArray recommend_array;
    private RequestQueue requestQueue;
    private TextView textView_loading;
    private ProgressBar pgsBar;
    private YouTubePlayerView youTubePlayerView;
    private TextView title;
    private TextView genre;
    private TextView overview;
    private TextView year;
    private TextView genre_title;
    private TextView overview_title;
    private TextView year_title;
    private ImageView watchlist_icon;
    private ImageView fb_icon;
    private ImageView tw_icon;
    private CardView detail_title_card;
    private ImageView no_video;
    private detailActivity cur_activity;


    /**
     * Called when the activity is first created.
     */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail);
        cur_activity=this;

        media_type = getIntent().getStringExtra("media_type");
        id =getIntent().getIntExtra("id",0);
        requestQueue = Volley.newRequestQueue(this);
        pgsBar = (ProgressBar) findViewById(R.id.pBar_home);
        textView_loading=findViewById(R.id.loadingText_home);
        youTubePlayerView = findViewById(R.id.youtube_player_view);
        title= findViewById(R.id.detail_title);
        overview=findViewById(R.id.overview);
        genre=findViewById(R.id.genre);
        year=findViewById(R.id.year);
        watchlist_icon=findViewById(R.id.watchlist_icon);
        genre_title=findViewById(R.id.title_genre);
        overview_title=findViewById(R.id.title_overview);
        year_title=findViewById(R.id.title_year);
        fb_icon=findViewById(R.id.share_fb);
        tw_icon=findViewById(R.id.share_tw);
        no_video=findViewById(R.id.no_video);
        detail_title_card=findViewById(R.id.detail_title_card);
        home_vertical_scrollView=findViewById(R.id.home_vertical_scrollView);


        init_watchlist_icon();
        onclick_watchlist();
        init_fb_tw();
//        getLifecycle().addObserver(youTubePlayerView);
        jsonParse();


    }

    private void init_fb_tw(){
        Glide.with(this)
                .load(getDrawable(R.drawable.ic_baseline_facebook_24))
                .fitCenter()
                .into(fb_icon);
        Glide.with(this)
                .load(getDrawable(R.drawable.ic_twitter_logo_dialog))
                .fitCenter()
                .into(tw_icon);

        fb_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("https://www.facebook.com/sharer/sharer.php?u="+"https://www.themoviedb.org/"+media_type+"/"+id);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                v.getContext().startActivity(intent);
            }
        });

        tw_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("https://twitter.com/intent/tweet?text="+"Check this out!%0D%0A"+"https://www.themoviedb.org/"+media_type+"/"+id);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                v.getContext().startActivity(intent);
            }
        });

    }

    private void onclick_watchlist(){
        watchlist_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences pref = v.getContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
                JSONArray tmp_array= null;
                SharedPreferences.Editor editor = pref.edit();
                if (found){
                    try {
                        tmp_array = new JSONArray(pref.getString("watchlist", null));
                        int tmp_pos=0;
                        String tmp_name="";
                        for (int i = 0; i < tmp_array.length(); i++) {
                            if (tmp_array.getJSONObject(i).getInt("id")==id & tmp_array.getJSONObject(i).getString("media_type").equals(media_type)){
                                tmp_pos=i;
                                tmp_name=tmp_array.getJSONObject(i).getString("name");
                            }
                        }

                        tmp_array.remove(tmp_pos);
                        editor.putString("watchlist", tmp_array.toString()); // Storing string
                        editor.apply(); // commit changes
                        Glide.with(v)
                                .load(getDrawable(R.drawable.ic_baseline_add_circle_outline_24))
                                .fitCenter()
                                .into(watchlist_icon);
                        Toast.makeText(v.getContext(), tmp_name+ " was removed from the Watchlist", Toast.LENGTH_SHORT).show();
                        found=false;

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else{
                    try {
                        tmp_array = new JSONArray(pref.getString("watchlist", null));
                        JSONObject tmp_obj=new JSONObject();
                        tmp_obj.put("id",id);
                        tmp_obj.put("media_type",media_type);
                        tmp_obj.put("poster_path",poster_path);
                        tmp_obj.put("name",name);
                        tmp_array.put(tmp_obj);
                        editor.putString("watchlist", tmp_array.toString()); // Storing string
                        editor.apply(); // commit changes


                        Glide.with(v)
                                .load(getDrawable(R.drawable.ic_baseline_remove_circle_outline_24))
                                .fitCenter()
                                .into(watchlist_icon);
                        found=true;
                        Toast.makeText(v.getContext(), name+ " was added to the Watchlist", Toast.LENGTH_SHORT).show();

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }


            }
        });
    }

    private void init_watchlist_icon(){

        SharedPreferences pref = this.getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode

        JSONArray tmp_array=new JSONArray();
        if (pref.getString("watchlist", null) !=null){
            try {
                tmp_array=new JSONArray(pref.getString("watchlist", null));

                for (int i = 0; i < tmp_array.length(); i++) {
                    if (tmp_array.getJSONObject(i).getInt("id")==id & tmp_array.getJSONObject(i).getString("media_type").equals(media_type)){
                        found=true;
                    }
                }
                if (found){
                    Glide.with(this)
                            .load(getDrawable(R.drawable.ic_baseline_remove_circle_outline_24))
                            .fitCenter()
                            .into(watchlist_icon);


                }
                else{
                    Glide.with(this)
                            .load(getDrawable(R.drawable.ic_baseline_add_circle_outline_24))
                            .fitCenter()
                            .into(watchlist_icon);

                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else{

            Glide.with(this)
                    .load(getDrawable(R.drawable.ic_baseline_add_circle_outline_24))
                    .fitCenter()
                    .into(watchlist_icon);

        }
    }

    private void initial_cast(JSONArray cast_array) throws JSONException {
        // get the reference of RecyclerView
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView_cast);
        TextView cast_title=findViewById(R.id.title_cast);
        if (cast_array.length()==0){
            cast_title.setVisibility(View.GONE);
            recyclerView.setVisibility(View.GONE);
        }
        else{
            cast_title.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.VISIBLE);
            // set a GridLayoutManager with default vertical orientation and 3 number of columns
            GridLayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(),3);
            recyclerView.setLayoutManager(gridLayoutManager); // set LayoutManager to RecyclerView
            //  call the constructor of CustomAdapter to send the reference and data to Adapter
            castAdapter customAdapter = new castAdapter(cast_array);


            recyclerView.setAdapter(customAdapter); // set the Adapter to RecyclerView
        }

    }
    private void initial_review(JSONArray review_array) throws JSONException {
        // get the reference of RecyclerView
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView_review);
        TextView review_title=findViewById(R.id.title_review);
        if (review_array.length()==0){
            review_title.setVisibility(View.GONE);
            recyclerView.setVisibility(View.GONE);
        }
        else{
            review_title.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.VISIBLE);
            LinearLayoutManager VerticalLayoutManager
                    = new LinearLayoutManager(
                    getApplicationContext(),
                    LinearLayoutManager.VERTICAL,
                    false);
            recyclerView.setLayoutManager(VerticalLayoutManager); // set LayoutManager to RecyclerView
            //  call the constructor of CustomAdapter to send the reference and data to Adapter
            ReviewAdapter customAdapter = new ReviewAdapter(review_array);


            recyclerView.setAdapter(customAdapter); // set the Adapter to RecyclerView
        }

    }
    private void init_recommend(JSONArray recommend_array){
        TextView recommend_title=findViewById(R.id.title_recommend);
        if (recommend_array.length()==0){
            recommend_title.setVisibility(View.GONE);
        }
        else{
            // initialisation with id's
            recommend_title.setVisibility(View.VISIBLE);
            RecyclerView recyclerView
                    = (RecyclerView)findViewById(
                    R.id.recyclerview_recommend);
            RecyclerView.LayoutManager RecyclerViewLayoutManager
                    = new LinearLayoutManager(
                    getApplicationContext());

            // Set LayoutManager on Recycler View
            recyclerView.setLayoutManager(
                    RecyclerViewLayoutManager);



            // calling constructor of adapter
            // with source list as a parameter
            RecommendAdapter adapter = new RecommendAdapter(recommend_array);

            // Set Horizontal Layout Manager
            // for Recycler view
            LinearLayoutManager HorizontalLayout
                    = new LinearLayoutManager(
                    getApplicationContext(),
                    LinearLayoutManager.HORIZONTAL,
                    false);
            recyclerView.setLayoutManager(HorizontalLayout);

            // Set adapter on recycler view
            recyclerView.setAdapter(adapter);
        }



    }

    private void jsonParse() {
        String url;
        if (media_type.equals("movie")){
            url = "https://changge-csci571-hw9-backend.wm.r.appspot.com/MoviesDetails?id="+ id;
        }
        else{
            url = "https://changge-csci571-hw9-backend.wm.r.appspot.com/TVShowDetails?id="+ id;
        }
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                detail_array = response;
                try {
                    JSONObject tmp_obj=detail_array.getJSONObject(0);
                    name=tmp_obj.getString("name");
                    poster_path=tmp_obj.getString("poster_path");
                    title.setText(name);

                    Glide.with(cur_activity)
                            .load(tmp_obj.getString("backdrop_path"))
                            .fitCenter()
                            .into(no_video);


                    if (tmp_obj.getString("genres").isEmpty()){
                        genre_title.setVisibility(View.GONE);
                    }
                    else{
                        genre_title.setVisibility(View.VISIBLE);
                        genre.setText(tmp_obj.getString("genres"));
                    }

                    if (tmp_obj.getString("overview").isEmpty()){
                        overview_title.setVisibility(View.GONE);

                    }
                    else{
                        overview_title.setVisibility(View.VISIBLE);
                        overview.setText(tmp_obj.getString("overview"));
                    }

                    if (tmp_obj.getString("release_date").isEmpty()){
                        year_title.setVisibility(View.GONE);
                    }
                    else{
                        year_title.setVisibility(View.VISIBLE);
                        year.setText(tmp_obj.getString("release_date"));
                    }



//                    overview.setText(getString(R.string.pre_string));




                } catch (JSONException e) {
                    e.printStackTrace();
                }

//                Log.i("detail_array:",detail_array.toString());

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        if (media_type.equals("movie")){
            url = "https://changge-csci571-hw8-backend.wl.r.appspot.com/MoviesVideo?id="+ id;
        }
        else{
            url = "https://changge-csci571-hw8-backend.wl.r.appspot.com/TVShowVideo?id="+ id;
        }
        Log.i("id:", String.valueOf(id));
        JsonArrayRequest request2 = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                video_array=response;


                if (video_array.length()==0)
                {
                    no_video.setVisibility(View.VISIBLE);
                    youTubePlayerView.setVisibility(View.GONE);
                    RelativeLayout.LayoutParams p = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                    p.addRule(RelativeLayout.BELOW, R.id.no_video);
                    detail_title_card.setLayoutParams(p);
                }
                else{
                    youTubePlayerView.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
                        @Override
                        public void onReady(@NonNull YouTubePlayer youTubePlayer) {
                            String videoId = null;
                            try {
                                videoId = video_array.getJSONObject(0).getString("key");
                                youTubePlayer.loadVideo(videoId, 0);
                                youTubePlayer.pause();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    });
                }
//                Log.i("video_array:",video_array.toString());





            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        if (media_type.equals("movie")){
            url = "https://changge-csci571-hw9-backend.wm.r.appspot.com/MovieCast?id="+ id;
        }
        else{
            url = "https://changge-csci571-hw9-backend.wm.r.appspot.com/TVShowCast?id="+ id;
        }

        JsonArrayRequest request3 = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                cast_array=response;
                try {
                    initial_cast(cast_array);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
//                Log.i("cast_array:",cast_array.toString());
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        if (media_type.equals("movie")){
            url = "https://changge-csci571-hw9-backend.wm.r.appspot.com/MoviesReviews?id="+ id;
        }
        else{
            url = "https://changge-csci571-hw9-backend.wm.r.appspot.com/TVShowReviews?id="+ id;
        }
        JsonArrayRequest request4 = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                review_array =response;
                try {
                    initial_review(review_array);

                } catch (JSONException e) {
                    e.printStackTrace();
                }


//                home_vertical_scrollView.setVisibility(View.VISIBLE);

//                Log.i("cast_array:",cast_array.toString());
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        if (media_type.equals("movie")){
            url = "https://changge-csci571-hw9-backend.wm.r.appspot.com/RecommendedMovies?id="+ id;
        }
        else{
            url = "https://changge-csci571-hw9-backend.wm.r.appspot.com/RecommendedTVShows?id="+ id;
        }

        JsonArrayRequest request5 = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                recommend_array=response;
                init_recommend(recommend_array);
                home_vertical_scrollView.setVisibility(View.VISIBLE);
                pgsBar.setVisibility(View.GONE);
                textView_loading.setVisibility(View.GONE);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        requestQueue.add(request);
        requestQueue.add(request2);
        requestQueue.add(request3);
        requestQueue.add(request4);
        requestQueue.add(request5);
    }
}
