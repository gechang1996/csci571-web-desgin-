const express = require('express');
const request = require('request');
var cors = require('cors');
const app = express();
app.use(cors());


const month={'01':'January',
'02':'February',
'03':'March',
'04':'April',
'05':'May',
'06':'June',
'07':'July',
'08':'August',
'09':'September',
'10':'October',
'11':'November',
'12':'December',
}

//4.1.1 Multi-Search Endpoint to search for both Movies and TV sho
app.get('/search', (req, res) => {
  var search_keyword=req.query.keyword;
  
  var my_url='https://api.themoviedb.org/3/search/multi?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&query='+search_keyword
request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	var results=JSON.parse(response.body).results;
	var return_list=[];
	var tmp_obj={};
	var count=0;
	
	for(num in results){
		if (results[num]['media_type']!='tv' && results[num]['media_type']!='movie'){
			continue;
		}
		tmp_obj={};
		if (results[num]['backdrop_path']==null){
			continue;
		}
		tmp_obj['backdrop_path']='https://image.tmdb.org/t/p/w500'+results[num]['backdrop_path'];
		tmp_obj['poster_path']='https://image.tmdb.org/t/p/w500'+results[num]['poster_path'];
		tmp_obj['id']=results[num]['id'];
		tmp_obj['vote_average']=results[num]['vote_average'];
		tmp_obj['media_type']=results[num]['media_type'];
		
		if (results[num]['media_type']=='movie'){
			
			tmp_obj['name']=results[num]['title'];
			tmp_obj['release_date']=results[num]['release_date'].slice(0, 4);
			
		}
		else if (results[num]['media_type']=='tv'){
			
			tmp_obj['name']=results[num]['name'];
			tmp_obj['release_date']=results[num]['first_air_date'].slice(0, 4);
		}
		
		return_list.push(tmp_obj);
		count+=1;
		if (count>19){
			break;
		}
	}
	
	res.send(return_list);
  }
});
});

//4.1.4 Currently playing Movies Endpoint 6 images
app.get('/CurrentPlayingMovies', (req, res) => {
	var count=0;
  var my_url='https://api.themoviedb.org/3/movie/now_playing?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&page=1'
  request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	var results=JSON.parse(response.body).results;
	var return_list=[];
	var tmp_obj={};
	for(num in results){
		
		tmp_obj={};
		if (results[num]['backdrop_path']==null){
			continue;
		}
		tmp_obj['poster_path']='https://image.tmdb.org/t/p/w1280' +results[num]['poster_path'];
		tmp_obj['id']=results[num]['id'];
		tmp_obj['media_type']="movie";
		tmp_obj['name']=results[num]['title'];			
		return_list.push(tmp_obj);
		count+=1;
		if (count>5){
			break;
		}
	}
	res.send(return_list);
  }
});

});


//4.1.12 Trending TV Shows Endpoint with 6 images
app.get('/TrendingTVShows', (req, res) => {
  var count=0;
  var my_url='https://api.themoviedb.org/3/trending/tv/day?api_key=8715391ef412e5f7d261af4a4cf78da4'
  request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	var results=JSON.parse(response.body).results;
	var return_list=[];
	var tmp_obj={};
	for(num in results){
		tmp_obj={};
		if (results[num]['poster_path']==null){
			continue;
		}
		tmp_obj['media_type']="tv";
		tmp_obj['id']=results[num]['id'];
		tmp_obj['name']=results[num]['name'];	
		tmp_obj['poster_path']="https://image.tmdb.org/t/p/w500"+results[num]['poster_path'];	
		return_list.push(tmp_obj);
		count+=1;
		if (count>5){
			break;
		}
	}
	res.send(return_list);
  }
});
});

//4.1.3 Top-Rated Movies Endpoint
app.get('/Top-RatedMovies', (req, res) => {
	var count=0;
  var my_url='https://api.themoviedb.org/3/movie/top_rated?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&page=1'
  request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	var results=JSON.parse(response.body).results;
	var return_list=[];
	var tmp_obj={};
	for(num in results){
		
		tmp_obj={};
		if (results[num]['poster_path']==null){
			continue;
		}
		tmp_obj['media_type']="movie";
		tmp_obj['poster_path']='https://image.tmdb.org/t/p/w500' +results[num]['poster_path'];
		tmp_obj['id']=results[num]['id'];
		tmp_obj['name']=results[num]['title'];			
		return_list.push(tmp_obj);
		count+=1;
		if (count>9){
			break;
		}
	}
	res.send(return_list);
  }
});

});

//4.1.13 Top-Rated TV shows Endpoin
app.get('/Top-RatedTVShows', (req, res) => {
var count=0;
  var my_url='https://api.themoviedb.org/3/tv/top_rated?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&page=1'
  request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	var results=JSON.parse(response.body).results;
	var return_list=[];
	var tmp_obj={};
	for(num in results){
		tmp_obj={};
		if (results[num]['poster_path']==null){
			continue;
		}
		tmp_obj['media_type']="tv";
		tmp_obj['id']=results[num]['id'];
		tmp_obj['name']=results[num]['name'];	
		tmp_obj['poster_path']="https://image.tmdb.org/t/p/w500"+results[num]['poster_path'];	
		return_list.push(tmp_obj);
		count+=1;
		if (count>9){
			break;
		}
	}
	res.send(return_list);
  }
});
});

//4.1.5 Popular Movies Endpoint
app.get('/PopularMovies', (req, res) => {
	var count=0;
  var my_url='https://api.themoviedb.org/3/movie/popular?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&page=1'
  request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	var results=JSON.parse(response.body).results;
	var return_list=[];
	var tmp_obj={};
	for(num in results){
		tmp_obj={};
		if (results[num]['poster_path']==null){
			continue;
		}
		tmp_obj['media_type']="movie";
		tmp_obj['poster_path']='https://image.tmdb.org/t/p/w500' +results[num]['poster_path'];
		tmp_obj['id']=results[num]['id'];
		tmp_obj['name']=results[num]['title'];			
		return_list.push(tmp_obj);
		count+=1;
		if (count>9){
			break;
		}
	}
	res.send(return_list);
  }
});

});

//4.1.14 Popular TV shows Endpoint
app.get('/PopularTVShows', (req, res) => {
var count=0;
  var my_url='https://api.themoviedb.org/3/tv/popular?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&page=1'
  request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	var results=JSON.parse(response.body).results;
	var return_list=[];
	var tmp_obj={};
	for(num in results){
		tmp_obj={};
		if (results[num]['poster_path']==null){
			continue;
		}
		tmp_obj['media_type']="tv";
		tmp_obj['id']=results[num]['id'];
		tmp_obj['name']=results[num]['name'];	
		tmp_obj['poster_path']="https://image.tmdb.org/t/p/w500"+results[num]['poster_path'];	
		return_list.push(tmp_obj);
		count+=1;
		if (count>9){
			break;
		}
	}
	res.send(return_list);
  }
});
});
//4.1.9 Movie Details Endpoint
app.get('/MoviesDetails', (req, res) => {
  var movie_id=req.query.id;

  var my_url='https://api.themoviedb.org/3/movie/'+movie_id +'?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&page=1'
  request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	  
	var results=JSON.parse(response.body);
	
	var return_list=[];
	var tmp_obj={};
	
	
	
	tmp_obj['name']=results['title'];
	var tmp_genre='';
	for (num in results['genres']){
		tmp_genre+=results['genres'][num]['name'];
		tmp_genre+=', ';
	}
	
	tmp_obj['genres']=tmp_genre.slice(0, -2);
	var tmp_lang='';
	for(num in results['spoken_languages']){
		tmp_lang+=results['spoken_languages'][num]['english_name'];
		tmp_lang+=', ';
	}
	
	tmp_obj['spoken_languages']=tmp_lang.slice(0, -2);			
	tmp_obj['release_date']=results['release_date'].slice(0, 4);
	
	var minutes=parseInt(results['runtime']);
	var hours=Math.floor(minutes/60);
	tmp_runtime= hours+ 'hrs '+(minutes-hours*60)+'mins';
	
	tmp_obj['runtime']=tmp_runtime;	
	tmp_obj['overview']=results['overview'];	
	tmp_obj['vote_average']=results['vote_average'];	
	tmp_obj['tagline']=results['tagline'];	
	tmp_obj['backdrop_path']='https://image.tmdb.org/t/p/w1280' +results['backdrop_path'];
	tmp_obj['poster_path']='https://image.tmdb.org/t/p/w500' +results['poster_path'];
	return_list.push(tmp_obj);

	res.send(return_list);
  }
});
});

//4.1.18 TV show Details Endpoint
app.get('/TVShowDetails', (req, res) => {
  var tv_id=req.query.id;

  var my_url='https://api.themoviedb.org/3/tv/'+tv_id +'?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&page=1'
  request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	  
	var results=JSON.parse(response.body);
	
	var return_list=[];
	var tmp_obj={};
	
	
	
	tmp_obj['name']=results['name'];
	var tmp_genre='';
	for (num in results['genres']){
		tmp_genre+=results['genres'][num]['name'];
		tmp_genre+=', ';
	}
	
	tmp_obj['genres']=tmp_genre.slice(0, -2);
	var tmp_lang='';
	for(num in results['spoken_languages']){
		tmp_lang+=results['spoken_languages'][num]['english_name'];
		tmp_lang+=', ';
	}
	
	tmp_obj['spoken_languages']=tmp_lang.slice(0, -2);			
	tmp_obj['release_date']=results['first_air_date'].slice(0, 4);
	
	var minutes=parseInt(results['episode_run_time'][0]);
	var hours=Math.floor(minutes/60);
	tmp_runtime= hours+ 'hrs '+(minutes-hours*60)+'mins';
	
	tmp_obj['runtime']=tmp_runtime;	
	tmp_obj['overview']=results['overview'];	
	tmp_obj['vote_average']=results['vote_average'];	
	tmp_obj['tagline']=results['tagline'];
	tmp_obj['poster_path']='https://image.tmdb.org/t/p/w500' +results['poster_path'];
	tmp_obj['backdrop_path']='https://image.tmdb.org/t/p/w1280' +results['backdrop_path'];
	return_list.push(tmp_obj);

	res.send(return_list);
  }
});
});

//4.1.20 TV show Cast Endpoint
app.get('/TVShowCast', (req, res) => {
  var TV_id=req.query.id;
var count=0;
  var my_url='https://api.themoviedb.org/3/tv/'+TV_id+'/credits?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&page=1'
  request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	var results=JSON.parse(response.body).cast;
	var return_list=[];
	var tmp_obj={};
	for(num in results){
		tmp_obj={};
		if (results[num]['profile_path']==null){
			continue;
		}
		
		
		tmp_obj['id']=results[num]['id'];
		tmp_obj['name']=results[num]['name'];
		tmp_obj['character']=results[num]['character'];		

				
		tmp_obj['profile_path']="https://image.tmdb.org/t/p/w500"+results[num]['profile_path'];	
		return_list.push(tmp_obj);
		count+=1;
		if (count>5){
			break;
		}
	}
	res.send(return_list);
  }
});
});

//4.1.11 Movie Cast Endpoint
app.get('/MovieCast', (req, res) => {
  var movie_id=req.query.id;
var count=0;
  var my_url='https://api.themoviedb.org/3/movie/'+movie_id+'/credits?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&page=1'
  request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	var results=JSON.parse(response.body).cast;
	var return_list=[];
	var tmp_obj={};
	for(num in results){
		tmp_obj={};
		if (results[num]['profile_path']==null){
			continue;
		}
		
		
		tmp_obj['id']=results[num]['id'];
		tmp_obj['name']=results[num]['name'];
		tmp_obj['character']=results[num]['character'];		

				
		tmp_obj['profile_path']="https://image.tmdb.org/t/p/w500"+results[num]['profile_path'];	
		return_list.push(tmp_obj);
		count+=1;
		if (count>5){
			break;
		}
	}
	res.send(return_list);
  }
});
});

app.get('/movie', (req, res) => {
  var movie_id=req.query.id;
  
 
  res.send(movie_id);
});

//4.1.10 Movie Reviews Endpoint
app.get('/MoviesReviews', (req, res) => {
  var movie_id=req.query.id;

  var my_url='https://api.themoviedb.org/3/movie/'+movie_id +'/reviews?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&page=1'
  request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	  
	var results=JSON.parse(response.body).results;
	
	var return_list=[];
	var tmp_obj={};
	tmp_date='';
	
	for(num in results){
		tmp_obj={};
		
		tmp_obj['author']=results[num]['author'];
		tmp_obj['content']=results[num]['content'];
		tmp_date=month[results[num]['created_at'].slice(5, 7)]+" "+results[num]['created_at'].slice(8, 10)+", "+results[num]['created_at'].slice(0, 4);
	
		
		
		tmp_obj['created_at']=tmp_date;			
		tmp_obj['url']=results[num]['url'];	
		if (results[num]['author_details']['rating']==null){
			tmp_obj['rating']=0;	
		}
		else{
			tmp_obj['rating']=results[num]['author_details']['rating'];	
		}
		
		
		if (results[num]['author_details']['avatar_path']==null){
			tmp_obj['avatar_path']='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHnPmUvFLjjmoYWAbLTEmLLIRCPpV_OgxCVA&usqp=CAU';
		}
		else if(results[num]['author_details']['avatar_path'].slice(1, 5)=="http"){
			tmp_obj['avatar_path']=results[num]['author_details']['avatar_path'].substring(1);
			
		}
		else{
			tmp_obj['avatar_path']='https://image.tmdb.org/t/p/original'+results[num]['author_details']['avatar_path'];
		}
		
		return_list.push(tmp_obj);
		if (return_list.length>=3){
			break;
		}
	}

	res.send(return_list);
  }
});
});

//4.1.19 TV show Reviews Endpoint
app.get('/TVShowReviews', (req, res) => {
  var TV_id=req.query.id;

  var my_url='https://api.themoviedb.org/3/tv/'+TV_id +'/reviews?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&page=1'
  request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	  
	var results=JSON.parse(response.body).results;
	
	var return_list=[];
	var tmp_obj={};
	tmp_date='';
	for(num in results){
		tmp_obj={};
		
		tmp_obj['author']=results[num]['author'];
		tmp_obj['content']=results[num]['content'];
		tmp_date=month[results[num]['created_at'].slice(5, 7)]+" "+results[num]['created_at'].slice(8, 10)+", "+results[num]['created_at'].slice(0, 4);
		
		
		
		tmp_obj['created_at']=tmp_date;			
		tmp_obj['url']=results[num]['url'];	
		if(results[num]['author_details']['rating']==null)
		{
			tmp_obj['rating']=0;	
		}
		else{
			tmp_obj['rating']=results[num]['author_details']['rating'];	
		}
		
		
		if (results[num]['author_details']['avatar_path']==null){
			tmp_obj['avatar_path']='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRHnPmUvFLjjmoYWAbLTEmLLIRCPpV_OgxCVA&usqp=CAU';
		}
		else if(results[num]['author_details']['avatar_path'].slice(1, 5)=="http"){
			tmp_obj['avatar_path']=results[num]['author_details']['avatar_path'].substring(1);
			
		}
		else{
			tmp_obj['avatar_path']='https://image.tmdb.org/t/p/original'+results[num]['author_details']['avatar_path'];
		}
		
		return_list.push(tmp_obj);
		if (return_list.length>=3){
			break;
		}
	}

	res.send(return_list);
  }
});
});
//4.1.6 Recommended Movies Endpoint
app.get('/RecommendedMovies', (req, res) => {
  var movie_id=req.query.id;

  var my_url='https://api.themoviedb.org/3/movie/'+movie_id+'/recommendations?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&page=1'
  request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	var results=JSON.parse(response.body).results;
	var return_list=[];
	var tmp_obj={};
	for(num in results){
		tmp_obj={};
		if (results[num]['poster_path']==null){
			continue;
		}
		tmp_obj['poster_path']='https://image.tmdb.org/t/p/w500' +results[num]['poster_path'];
		tmp_obj['id']=results[num]['id'];
		tmp_obj['name']=results[num]['title'];		
		tmp_obj['media_type']='movie';			
		return_list.push(tmp_obj);
		if (return_list.length>=10){
			break;
		}
	}
	res.send(return_list);
  }
});

});

//4.1.15 Recommended TV shows Endpoint
app.get('/RecommendedTVShows', (req, res) => {
  var TV_id=req.query.id;

  var my_url='https://api.themoviedb.org/3/tv/'+TV_id+'/recommendations?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&page=1'
  request(my_url, function (error, response, body) {
  if (!error && response.statusCode == 200) {
	var results=JSON.parse(response.body).results;
	var return_list=[];
	var tmp_obj={};
	for(num in results){
		tmp_obj={};
		if (results[num]['poster_path']==null){
			continue;
		}
		tmp_obj['poster_path']='https://image.tmdb.org/t/p/w500' +results[num]['poster_path'];
		tmp_obj['id']=results[num]['id'];
		tmp_obj['name']=results[num]['name'];			
		tmp_obj['media_type']='tv';	
		return_list.push(tmp_obj);
		if (return_list.length>=10){
			break;
		}
	}
	res.send(return_list);
  }
});

});


const server = app.listen(8081, () => {
  const host = server.address().address;
  const port = server.address().port;

  console.log(`Example app listening at http://${host}:${port}`);
});