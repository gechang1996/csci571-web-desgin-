from flask import Flask, jsonify,request
import requests
from flask_cors import CORS
app = Flask(__name__,static_url_path='',static_folder='static')
CORS(app)

@app.route('/index.html')
def root():
    print('Executing /')
    return app.send_static_file('HW6.html')



@app.route("/trending",methods=['GET'])
def trending():
    media_type="movie"
    time_window="week"
    api_key="8715391ef412e5f7d261af4a4cf78da4"
    
    
    response=requests.get("https://api.themoviedb.org/3/trending/"+media_type+"/"+time_window+"?api_key="+api_key,timeout=10)
    
    response=response.json()['results'][0:5]
    
    result=[]
    for ele in response:
        tmp_ele={}
        tmp_ele["title"]=ele["title"]
        tmp_ele["backdrop_path"]=ele["backdrop_path"]
        tmp_ele["release_date"]=ele["release_date"]
        result.append(tmp_ele)
    
    response=jsonify(result)
    response.headers.add("Access-Control-Allow-Origin", "*")
    return  response
    
    
@app.route("/TV",methods=['GET'])
def TV():
    media_type="tv"
    time_window="airing_today"
    api_key="8715391ef412e5f7d261af4a4cf78da4"
    
    
    response=requests.get("https://api.themoviedb.org/3/tv/airing_today?api_key=8715391ef412e5f7d261af4a4cf78da4",timeout=10)
    
    response=response.json()['results'][0:5]
    
    result=[]
    for ele in response:
        tmp_ele={}
        tmp_ele["name"]=ele["name"]
        tmp_ele["backdrop_path"]=ele["backdrop_path"]
        tmp_ele["first_air_date"]=ele["first_air_date"]
        result.append(tmp_ele)
    
    response=jsonify(result)
    response.headers.add("Access-Control-Allow-Origin", "*")
    return  response

@app.route("/search_movie/",methods=['GET'])
def search_movie():
    
    my_html="https://api.themoviedb.org/3/search/movie?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&query="+request.args.get("search")+"&page=1&include_adult=false"
    response=requests.get(my_html,timeout=10)
    response=response.json()['results']
    genres=requests.get("https://api.themoviedb.org/3/genre/movie/list?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US",timeout=10)
    genres=genres.json()["genres"]
    genres_dic={}
    for tmp_genre in genres:
        genres_dic[int(tmp_genre["id"])]=tmp_genre["name"]
        
    
    result=[]
    for ele in response:
        
        tmp_ele={}
        tmp_ele["id"]=ele["id"]
        tmp_ele["title"]=ele["title"]
        tmp_ele["overview"]=ele["overview"]
        tmp_ele["poster_path"]=ele["poster_path"]
        tmp_ele["release_date"]=ele["release_date"]
        tmp_ele["vote_average"]=ele["vote_average"]
        tmp_ele["vote_count"]=ele["vote_count"]
        tmp_ele["media_type"]="movie"
        tmp_str=""
        for genre_id in ele["genre_ids"]:
            tmp_str+=genres_dic[genre_id]
            tmp_str+=","
        
        tmp_ele["genre_ids"]=tmp_str[:-1]
        result.append(tmp_ele)
        
    
    response=jsonify(result[0:10])
    response.headers.add("Access-Control-Allow-Origin", "*")
    return  response
    
    
@app.route("/search_TV/",methods=['GET'])
def search_TV():
    
    my_html="https://api.themoviedb.org/3/search/tv?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&query="+request.args.get("search")+"&page=1&include_adult=false"
    response=requests.get(my_html,timeout=10)
    response=response.json()['results']
    genres=requests.get("https://api.themoviedb.org/3/genre/tv/list?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US",timeout=10)
    genres=genres.json()["genres"]
    genres_dic={}
    for tmp_genre in genres:
        genres_dic[int(tmp_genre["id"])]=tmp_genre["name"]
       
    
    result=[]
    for ele in response:
       
        tmp_ele={}
        tmp_ele["id"]=ele["id"]
        tmp_ele["title"]=ele["name"]
        tmp_ele["overview"]=ele["overview"]
        tmp_ele["poster_path"]=ele["poster_path"]
        tmp_ele["release_date"]=ele["first_air_date"]
        tmp_ele["vote_average"]=ele["vote_average"]
        tmp_ele["vote_count"]=ele["vote_count"]
        tmp_ele["media_type"]="tv"
        tmp_str=""
        for genre_id in ele["genre_ids"]:
            tmp_str+=genres_dic[genre_id]
            tmp_str+=","
        
        tmp_ele["genre_ids"]=tmp_str[:-1]
        result.append(tmp_ele)
        
    
    response=jsonify(result[0:10])
    response.headers.add("Access-Control-Allow-Origin", "*")
    return  response
    
@app.route("/search_both/",methods=['GET'])
def search_both():
    
    my_html="https://api.themoviedb.org/3/search/multi?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US&query="+request.args.get("search")+"&page=1&include_adult=false"
    response=requests.get(my_html,timeout=10)
    response=response.json()['results']
    genres_tv=requests.get("https://api.themoviedb.org/3/genre/tv/list?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US",timeout=10)
    genres_tv=genres_tv.json()["genres"]
    genres_dic_tv={}
    for tmp_genre in genres_tv:
        genres_dic_tv[int(tmp_genre["id"])]=tmp_genre["name"]
        
    genres_movie=requests.get("https://api.themoviedb.org/3/genre/movie/list?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US",timeout=10)
    genres_movie=genres_movie.json()["genres"]
    genres_dic_movie={}
    for tmp_genre in genres_movie:
        genres_dic_movie[int(tmp_genre["id"])]=tmp_genre["name"]
        
        
    result=[]
    for ele in response:
        if ele["media_type"]=="tv" or ele["media_type"]=="movie":
            
            tmp_ele={}
            tmp_ele["id"]=ele["id"]
            tmp_ele["overview"]=ele["overview"]
            tmp_ele["poster_path"]=ele["poster_path"]
            tmp_ele["vote_average"]=ele["vote_average"]
            tmp_ele["vote_count"]=ele["vote_count"]
            tmp_str=""
            if ele["media_type"]=="tv":
                tmp_ele["title"]=ele["name"]
                tmp_ele["release_date"]=ele["first_air_date"]
                tmp_ele["media_type"]="tv"
                for genre_id in ele["genre_ids"]:
                    tmp_str+=genres_dic_tv[genre_id]
                    tmp_str+=","
                
            else:
                tmp_ele["release_date"]=ele["release_date"]
                tmp_ele["title"]=ele["title"]
                tmp_ele["media_type"]="movie"
                for genre_id in ele["genre_ids"]:
                    tmp_str+=genres_dic_movie[genre_id]
                    tmp_str+=","
            

            tmp_ele["genre_ids"]=tmp_str[:-1]
            result.append(tmp_ele)
           
    
    response=jsonify(result[0:10])
    response.headers.add("Access-Control-Allow-Origin", "*")
    return  response
    

@app.route("/movie_details/",methods=['GET'])
def movie_details():
    
    my_html="https://api.themoviedb.org/3/movie/"+request.args.get("id")+"?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US"
    response=requests.get(my_html,timeout=10)
    response=response.json()
    
        
    
    ele=response    
        
    
    
    
    tmp_ele={}
    tmp_ele["id"]=ele["id"]
    tmp_ele["title"]=ele["title"]
    tmp_ele["runtime"]=ele["runtime"]
    tmp_ele["poster_path"]=ele["poster_path"]
    tmp_ele["release_date"]=ele["release_date"]
    tmp_ele["vote_average"]=ele["vote_average"]
    tmp_ele["vote_count"]=ele["vote_count"]
    tmp_ele["backdrop_path"]=ele["backdrop_path"]
    tmp_ele["overview"]=ele["overview"]
    genres_str=""
    for genre in ele["genres"]:
        genres_str+=genre['name']
        genres_str+=","
    
    language_str=""
    for language in ele["spoken_languages"]:
        language_str+=language["english_name"]
        language_str+=","
    
    tmp_ele["genres"]=genres_str[:-1]
    tmp_ele["spoken_languages"]=language_str[:-1]
        
   
    response=jsonify(tmp_ele)
    response.headers.add("Access-Control-Allow-Origin", "*")
    return  response
    


@app.route("/tv_details/",methods=['GET'])
def tv_details():
    
    my_html="https://api.themoviedb.org/3/tv/"+request.args.get("id")+"?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US"
    response=requests.get(my_html,timeout=10)
    response=response.json()
    
        
    
    ele=response    
        
    
    

    tmp_ele={}
    tmp_ele["id"]=ele["id"]
    tmp_ele["title"]=ele["name"]
    tmp_ele["runtime"]=ele["episode_run_time"]
    tmp_ele["poster_path"]=ele["poster_path"]
    tmp_ele["release_date"]=ele["first_air_date"]
    tmp_ele["vote_average"]=ele["vote_average"]
    tmp_ele["vote_count"]=ele["vote_count"]
    tmp_ele["backdrop_path"]=ele["backdrop_path"]
    tmp_ele["number_of_seasons"]=ele["number_of_seasons"]
    tmp_ele["overview"]=ele["overview"]
    genres_str=""
    for genre in ele["genres"]:
        genres_str+=genre['name']
        genres_str+=","
    
    language_str=""
    for language in ele["spoken_languages"]:
        language_str+=language["english_name"]
        language_str+=","
    
    tmp_ele["genres"]=genres_str[:-1]
    tmp_ele["spoken_languages"]=language_str[:-1]
        
   
    response=jsonify(tmp_ele)
    response.headers.add("Access-Control-Allow-Origin", "*")
    return  response


    

@app.route("/movie_credits/",methods=['GET'])
def movie_credits():
    
    my_html="https://api.themoviedb.org/3/movie/"+request.args.get("id")+"/credits?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US"
    response=requests.get(my_html,timeout=10)
    response=response.json()['cast']
    response=response[0:8]
    
    result=[]
    for ele in response:
       
        tmp_ele={}
        tmp_ele["name"]=ele["name"]
        tmp_ele["profile_path"]=ele["profile_path"]
        tmp_ele["character"]=ele["character"]
        result.append(tmp_ele)
        
       
        
    
    response=jsonify(result)
    response.headers.add("Access-Control-Allow-Origin", "*")
    return  response
    
@app.route("/tv_credits/",methods=['GET'])
def tv_credits():
    
    my_html="https://api.themoviedb.org/3/tv/"+request.args.get("id")+"/credits?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US"
    response=requests.get(my_html,timeout=10)
    response=response.json()['cast']
    response=response[0:8]
    
    result=[]
    for ele in response:
    
        tmp_ele={}
        tmp_ele["name"]=ele["name"]
        tmp_ele["profile_path"]=ele["profile_path"]
        tmp_ele["character"]=ele["character"]
        result.append(tmp_ele)
        
       
        
    
    response=jsonify(result)
    response.headers.add("Access-Control-Allow-Origin", "*")
    return  response

    

@app.route("/movie_reviews/",methods=['GET'])
def movie_reviews():
    
    my_html="https://api.themoviedb.org/3/movie/"+request.args.get("id")+"/reviews?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US"
    response=requests.get(my_html,timeout=10)
    response=response.json()['results']
    response=response[0:5]
    
    result=[]
    for ele in response:
        tmp_ele={}
        tmp_ele["username"]=ele["author_details"]["username"]
        tmp_ele["content"]=ele["content"]
        tmp_ele["rating"]=ele["author_details"]["rating"]
        tmp_ele["created_at"]=ele["created_at"][0:10]
        
        result.append(tmp_ele)
        
       
        
    
    response=jsonify(result)
    response.headers.add("Access-Control-Allow-Origin", "*")
    return  response
    
    
@app.route("/tv_reviews/",methods=['GET'])
def tv_reviews():
    
    my_html="https://api.themoviedb.org/3/tv/"+request.args.get("id")+"/reviews?api_key=8715391ef412e5f7d261af4a4cf78da4&language=en-US"
    response=requests.get(my_html,timeout=10)
    response=response.json()['results']
    response=response[0:5]
    
    result=[]
    for ele in response:
        tmp_ele={}
        tmp_ele["username"]=ele["author_details"]["username"]
        tmp_ele["content"]=ele["content"]
        tmp_ele["rating"]=ele["author_details"]["rating"]
        tmp_ele["created_at"]=ele["created_at"][0:10]
        
        result.append(tmp_ele)
        
       
        
    
    response=jsonify(result)
    response.headers.add("Access-Control-Allow-Origin", "*")
    return  response