import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MylistComponent } from './mylist/mylist.component';
import { HomeComponent } from './home/home.component';
import { MovieComponent } from './movie/movie.component';
import { TvComponent } from './tv/tv.component';


const routes: Routes = [{ path: 'mylist', component: MylistComponent },
{ path: '', component: HomeComponent },
{ path: 'watch/movie/:id', component: MovieComponent },
{ path: 'watch/tv/:id', component: TvComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
