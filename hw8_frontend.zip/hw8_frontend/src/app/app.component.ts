import { ElementRef,ViewChild,Component,AfterViewInit,ViewEncapsulation } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import {Observable, OperatorFunction} from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { debounceTime, distinctUntilChanged, switchMap, catchError , map } from 'rxjs/operators';


var statesWithposters: {name: string, backdrop_path: string,poster_path: string ,id:string}[] = [];

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent {
  public model: any;
  public id:any;
  show_menu:any;
  mobile:any;
  baseURL: string = "https://changge-csci571-hw8-backend.wl.r.appspot.com/?keyword=";
  constructor(private location: Location, private router: Router,private http: HttpClient) {
	if(window.screen.width<=500){
		  this.mobile=true;
	  }
	  else{
		  this.mobile=false;
	  }
	  this.show_menu=false;
	  }
  
     
  

  
  
  title = 'my-app';
 
  
  
  //set nav bars
  color_home='#FFFFFF';
  color_list='#808080';
  nav_state=0;
  
  a=setTimeout('',0);
  
  over1(){
	if (this.color_home=='#808080'){
		this.color_home='#D1D0CE';
	}
  }

  out1(){
    if (this.color_home=='#D1D0CE'){
		this.color_home='#808080';
	}
  }
  over2(){
    if (this.color_list=='#808080'){
		this.color_list='#D1D0CE';
	}
   
  }
  out2(){
    if (this.color_list=='#D1D0CE'){
		this.color_list='#808080';
	}
  }
  clickEvent1(){
	if (this.color_home=='#D1D0CE'){
		this.color_home='#FFFFFF';
		this.color_list='#808080';
	}
	this.show_menu=false;
	this.router.navigate(['/']);
	
  }
  clickEvent2(){
    if (this.color_list=='#D1D0CE'){
		this.color_list='#FFFFFF';
		this.color_home='#808080';
	}	
	
	this.show_menu=false;
	this.router.navigate(['/mylist']);
	
  }
  clickEvent3(){
	this.color_home='#FFFFFF';
	this.color_list='#808080';
	this.show_menu=false;
	this.router.navigate(['/']);
  }
  menuList(){
	  this.show_menu=!this.show_menu;
  }
  
  AddContinue(id,media_type,name,poster_path){
	let objArray;
	  if (localStorage.getItem('continue_movie')!=null){
	  objArray=JSON.parse(localStorage.getItem('continue_movie')||'[]');

	  let tmp_obj={};
	  
	  tmp_obj['id']=id;
	  tmp_obj['media_type']=media_type;
	  tmp_obj['name']=name;
	  tmp_obj['poster_path']=poster_path;
	  
	  objArray.push(tmp_obj);
	  objArray=objArray.filter((v,i,a)=>a.findIndex(t=>(t.id === v.id))===i);
  }
  else{
	  objArray=[{id:id,media_type:media_type,name:name,poster_path:poster_path}];
  }
	 
	  
	  localStorage.setItem('continue_movie', JSON.stringify(objArray));
	 
	  
	  this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>{
	  this.router.navigate(['/watch/'+media_type+'/'+id]);
	  window.scrollTo(0, 0);});
	  
	  
	  
	  
	
	  
  }
 
  

 
  //search item functions
  search: OperatorFunction<string, readonly {name,backdrop_path,poster_path, id}[]> = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
	  distinctUntilChanged(),
      // switchMap allows returning an observable rather than maps array
	  switchMap( (searchText) =>  this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/search?keyword=" + this.model, {responseType: 'json'}) ),

    )
	
	
  

  formatter = (x: {name: string}) => x.name;
   
   
      
    
  
}
