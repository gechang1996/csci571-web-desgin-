import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MylistComponent } from './mylist/mylist.component';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { MovieComponent } from './movie/movie.component';
import { TvComponent } from './tv/tv.component';
import { YouTubePlayerModule } from "@angular/youtube-player";

@NgModule({
  declarations: [
    AppComponent,
    MylistComponent,
    HomeComponent,
    MovieComponent,
    TvComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
	FormsModule,
	NgbModule,
	YouTubePlayerModule,
	HttpClientModule,
	
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
