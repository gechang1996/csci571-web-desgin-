import { Component, OnInit ,ViewChild ,ViewEncapsulation} from '@angular/core';
import { NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  encapsulation: ViewEncapsulation.None
})



export class HomeComponent implements OnInit {
	
  mobile: boolean;
  images: any;
  names: any;
  ids: any;
  posters: any;
  
  popular_movie_formatted: any;
  continue_movie_formatted:any;
  top_rated_movie_formatted:any;
  trending_movie_formatted:any;
 
  popular_tv_formatted: any;
  top_rated_tv_formatted:any;
  trending_tv_formatted:any;
  
  popular_movie: any;
  continue_movie:any;
  top_rated_movie:any;
  trending_movie:any;
 
  popular_tv: any;
  top_rated_tv:any;
  trending_tv:any;
  show_continue: boolean;
  
  constructor(private http: HttpClient,private router: Router) { }
  
  ngOnInit(): void {
	
	  if(window.screen.width<=500){
		  this.mobile=true;
	  }
	  else{
		  this.mobile=false;
	  }
	  
	  
	  this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/CurrentPlayingMovies", {responseType: 'json'}).subscribe(data =>{
	var current_playing=data;
	this.images=current_playing.map(a => a.backdrop_path);
	this.posters=current_playing.map(a => a.poster_path);
	this.names=current_playing.map(a => a.name);
	this.ids=current_playing.map(a => a.id);
	
    
  });
  
  var movie_data;
  var j;
  
  let continue_movie=JSON.parse(localStorage.getItem('continue_movie')||'[]');
	this.continue_movie_formatted=[];
	this.continue_movie=continue_movie;
	j = -1;
	this.show_continue=false;
	if (continue_movie.length>0){
		this.show_continue=true;
	}
	for (let i = 0; i < continue_movie.length; i++) {
    if (i % 6 == 0) {
        j++;
        this.continue_movie_formatted[j] = [];
        this.continue_movie_formatted[j].push(continue_movie[i]);
    }
    else {
        this.continue_movie_formatted[j].push(continue_movie[i]);
    }} 
	
	//popular movie
  this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/PopularMovies", {responseType: 'json'}).subscribe(data =>{
	movie_data=data;
	j = -1;
	this.popular_movie=data;
	this.popular_movie_formatted=[];
	for (let i = 0; i < movie_data.length; i++) {
    if (i % 6 == 0) {
        j++;
        this.popular_movie_formatted[j] = [];
        this.popular_movie_formatted[j].push(movie_data[i]);
    }
    else {
        this.popular_movie_formatted[j].push(movie_data[i]);
    }}
  });
	//top-rated movie
	 this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/Top-RatedMovies", {responseType: 'json'}).subscribe(data =>{
	movie_data=data;
	j = -1;
	this.top_rated_movie=data;
	this.top_rated_movie_formatted=[];
	for (let i = 0; i < movie_data.length; i++) {
    if (i % 6 == 0) {
        j++;
        this.top_rated_movie_formatted[j] = [];
        this.top_rated_movie_formatted[j].push(movie_data[i]);
    }
    else {
        this.top_rated_movie_formatted[j].push(movie_data[i]);
    }}
  });
	//trending movie
	 this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/trendingMovies", {responseType: 'json'}).subscribe(data =>{
	movie_data=data;
	j = -1;
	this.trending_movie=data;
	this.trending_movie_formatted=[];
	for (let i = 0; i < movie_data.length; i++) {
    if (i % 6 == 0) {
        j++;
        this.trending_movie_formatted[j] = [];
        this.trending_movie_formatted[j].push(movie_data[i]);
    }
    else {
        this.trending_movie_formatted[j].push(movie_data[i]);
    }}
  });
	//popular tv
	 this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/PopularTVShows", {responseType: 'json'}).subscribe(data =>{
	movie_data=data;
	j = -1;
	this.popular_tv=data;
	this.popular_tv_formatted=[];
	for (let i = 0; i < movie_data.length; i++) {
    if (i % 6 == 0) {
        j++;
        this.popular_tv_formatted[j] = [];
        this.popular_tv_formatted[j].push(movie_data[i]);
    }
    else {
        this.popular_tv_formatted[j].push(movie_data[i]);
    }}
  });
  //top-rated tv
	 this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/Top-RatedTVShows", {responseType: 'json'}).subscribe(data =>{
	movie_data=data;
	j = -1;
	this.top_rated_tv=data;
	this.top_rated_tv_formatted=[];
	for (let i = 0; i < movie_data.length; i++) {
    if (i % 6 == 0) {
        j++;
        this.top_rated_tv_formatted[j] = [];
        this.top_rated_tv_formatted[j].push(movie_data[i]);
    }
    else {
        this.top_rated_tv_formatted[j].push(movie_data[i]);
    }}
  });
  //trending tv
	 this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/TrendingTVShows", {responseType: 'json'}).subscribe(data =>{
	movie_data=data;
	j = -1;
	this.trending_tv=data;
	this.trending_tv_formatted=[];
	for (let i = 0; i < movie_data.length; i++) {
    if (i % 6 == 0) {
        j++;
        this.trending_tv_formatted[j] = [];
        this.trending_tv_formatted[j].push(movie_data[i]);
    }
    else {
        this.trending_tv_formatted[j].push(movie_data[i]);
    }}
  });
	
  }
  
  
  
  display_carousel_caption='None';
  brightness='100%';

  paused = false;
  unpauseOnArrow = false;
  pauseOnIndicator = false;
  pauseOnHover = true;
  pauseOnFocus = true;


  @ViewChild('carousel', {static : true}) carousel: NgbCarousel;

  



  togglePaused() {
    if (this.paused) {
      this.carousel.cycle();
    } else {
      this.carousel.pause();
    }
    this.paused = !this.paused;
  }

  onSlide(slideEvent: NgbSlideEvent) {
    if (this.unpauseOnArrow && slideEvent.paused &&
      (slideEvent.source === NgbSlideEventSource.ARROW_LEFT || slideEvent.source === NgbSlideEventSource.ARROW_RIGHT)) {
      this.togglePaused();
	  
    }
    if (this.pauseOnIndicator && !slideEvent.paused && slideEvent.source === NgbSlideEventSource.INDICATOR) {
      this.togglePaused();
	  
    }
  }
  
  
  onMouseOver(): void {

	//let slides=document.getElementsByClassName('carousel-indicators');
	//let slide = slides[0] as HTMLElement;
	//slide.style.backgroundColor = "transparent";

  }
  
  onMouseOut(): void{

	  
	  
	  
  }
  
  
  clickEvent1(index): void{
	  
	  //add localStorage
      let objArray;
	  if (localStorage.getItem('continue_movie')!=null){
	  objArray=JSON.parse(localStorage.getItem('continue_movie')||'[]');
	  let tmp_obj={};
	  tmp_obj['id']=this.ids[index];
	  tmp_obj['media_type']='movie';
	  tmp_obj['name']=this.names[index];
	  tmp_obj['poster_path']=this.posters[index];
	  objArray.push(tmp_obj);
	  objArray=objArray.filter((v,i,a)=>a.findIndex(t=>(t.id === v.id))===i);
  }
  else{
	  objArray=[{id:this.ids[index],media_type:'movie',name:this.names[index],poster_path:this.posters[index]}];
  }
	  localStorage.setItem('continue_movie', JSON.stringify(objArray));
	 
	 
      
	  this.router.navigate(['/watch/movie/'+this.ids[index]]);
	  
  }
  
  ClickCard(id,media_type,name,poster_path):void{
	  //add localStorage
	  let objArray;
	  if (localStorage.getItem('continue_movie')!=null){
	  objArray=JSON.parse(localStorage.getItem('continue_movie')||'[]');
	  let tmp_obj={};
	  tmp_obj['id']=id;
	  tmp_obj['media_type']=media_type;
	  tmp_obj['name']=name;
	  tmp_obj['poster_path']=poster_path;
	  objArray.push(tmp_obj);
	  objArray=objArray.filter((v,i,a)=>a.findIndex(t=>(t.id === v.id))===i);
  }
  else{
	  objArray=[{id:id,media_type:media_type,name:name,poster_path:poster_path}];
  }
	  localStorage.setItem('continue_movie', JSON.stringify(objArray));
	  
	  this.router.navigate(['/watch/'+media_type+'/'+id]);
	  window.scrollTo(0, 0);
  }

}

