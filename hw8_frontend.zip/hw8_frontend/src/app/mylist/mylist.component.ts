import { Component, OnInit,ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-mylist',
  templateUrl: './mylist.component.html',
  styleUrls: ['./mylist.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class MylistComponent implements OnInit {
	if_exist_in_watchinglist:boolean;
	watch_list_formatted:any;
	watch_list:any;
	mobile: boolean;
  constructor(private http: HttpClient,private router: Router) { }

  ngOnInit(): void {
	   if(window.screen.width<=500){
		  this.mobile=true;
	  }
	  else{
		  this.mobile=false;
	  }
	
	let watching_list=JSON.parse(localStorage.getItem('watching_list')||'[]');

	if (watching_list.length>0){

		this.if_exist_in_watchinglist=true;
		
		
	let j = -1;
	this.watch_list=watching_list;
	this.watch_list_formatted=[];
	for (let i = 0; i < watching_list.length; i++) {
    if (i % 6 == 0) {
        j++;
        this.watch_list_formatted[j] = [];
        this.watch_list_formatted[j].push(watching_list[i]);
    }
    else {
        this.watch_list_formatted[j].push(watching_list[i]);
    }} 
		
	}
	else{
		this.watch_list_formatted=[];
		this.if_exist_in_watchinglist=false;
	
	}

  }
  
  ClickCard(id,media_type,name,poster_path):void{
	  //add localStorage
	  let objArray;
	  if (localStorage.getItem('continue_movie')!=null){
		  
	  objArray=JSON.parse(localStorage.getItem('continue_movie')||'[]');
	  let tmp_obj={};
	  tmp_obj['id']=id;
	  tmp_obj['media_type']=media_type;
	  tmp_obj['name']=name;
	  tmp_obj['poster_path']=poster_path;
	  objArray.push(tmp_obj);
	  objArray=objArray.filter((v,i,a)=>a.findIndex(t=>(t.id === v.id))===i);

  }
  else{
	  objArray=[{id:id,media_type:media_type,name:name,poster_path:poster_path}];
  }
	  localStorage.setItem('continue_movie', JSON.stringify(objArray));
	  
	  this.router.navigate(['/watch/'+media_type+'/'+id]);
  }

}
