import { Component, OnInit,ViewEncapsulation,ViewChild } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import {Subject} from 'rxjs';
import {debounceTime} from 'rxjs/operators';
import {NgbAlert} from '@ng-bootstrap/ng-bootstrap';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-tv',
  templateUrl: './tv.component.html',
  styleUrls: ['./tv.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class TvComponent implements OnInit {

  constructor(private http: HttpClient,private activatedRoute: ActivatedRoute,private router: Router,private modalService: NgbModal) { 
  }
  private _success = new Subject<string>();
  mobile: boolean;
  id: any;
  youtube_info:any;
  details:any;
  casts:any;
  cast_details:any;
  cast_external:any;
  reviews:any;
  button_loaded:boolean;
  similar_formatted:any;
  similar:any;
  recommended_formatted:any;
  recommended:any;
  button_text:any;
  if_exist_in_watchinglist:boolean;
  similar_exist:boolean;
  recommended_exist:boolean;
  messageType:any;
  successMessage = '';
  
  
  @ViewChild('selfClosingAlert', {static: false}) selfClosingAlert: NgbAlert;
  
  ngOnInit(): void {
	  
		this.recommended_exist=false;
		this.similar_exist=false;
		
		this.button_loaded=false;
	  if(window.screen.width<=500){
		  this.mobile=true;
	  }
	  else{
		  this.mobile=false;
	  }
	

    this._success.subscribe(message => this.successMessage = message);
    this._success.pipe(debounceTime(5000)).subscribe(() => {
      if (this.selfClosingAlert) {
        this.selfClosingAlert.close();
      }
    });  
	  
	  
	  
	this.details={};
	this.casts=[];
	this.cast_details={};
	this.cast_external={};
	this.reviews=[];
	this.youtube_info="tzkWB85ULJY";
	const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    document.body.appendChild(tag);
	

	
	
	
	
	
	this.activatedRoute.params.subscribe(param => {
    this.id = Number(param.id);

    
  });
	let watching_list=JSON.parse(localStorage.getItem('watching_list')||'[]');

	if (watching_list.some(data => data.id === this.id)){
		this.button_text='Remove from Watchlist';
		this.if_exist_in_watchinglist=true;
		this.messageType='danger';
	}
	else{
		this.button_text='Add to Watchlist';
		this.if_exist_in_watchinglist=false;
		this.messageType='success';
	}
	
  
	this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/TVShowVideo?id="+this.id, {responseType: 'json'}).subscribe(data =>{
	if (data.length!=0){
		this.youtube_info=data[0].key;
	}
  });
  
  this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/TVShowDetails?id="+this.id, {responseType: 'json'}).subscribe(data =>{
	this.details=data[0];
	this.button_loaded=true;

  });
  
  
  this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/TVShowCast?id="+this.id, {responseType: 'json'}).subscribe(data =>{
	this.casts=data;
  });
  
  this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/TVShowReviews?id="+this.id, {responseType: 'json'}).subscribe(data =>{
	this.reviews=data;
  });
  
  //recommended_formatted movie
	 this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/RecommendedTVShows?id="+this.id, {responseType: 'json'}).subscribe(data =>{
	let movie_data=data;
	let j = -1;
	this.recommended=data;
	this.recommended_formatted=[];
	for (let i = 0; i < movie_data.length; i++) {
    if (i % 6 == 0) {
        j++;
        this.recommended_formatted[j] = [];
        this.recommended_formatted[j].push(movie_data[i]);
    }
    else {
        this.recommended_formatted[j].push(movie_data[i]);
    }}
	if (this.recommended_formatted.length!=0){
		this.recommended_exist=true;
	}

  });
  //similar_formatted movie
	 this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/SimilarTVShows?id="+this.id, {responseType: 'json'}).subscribe(data =>{
	let movie_data=data;
	let j = -1;
	this.similar=data;
	this.similar_formatted=[];
	for (let i = 0; i < movie_data.length; i++) {
    if (i % 6 == 0) {
        j++;
        this.similar_formatted[j] = [];
        this.similar_formatted[j].push(movie_data[i]);
    }
    else {
        this.similar_formatted[j].push(movie_data[i]);
    }}
	
	if (this.similar_formatted.length!=0){
		this.similar_exist=true;
	}
	

  });
	
  }
  
  public changeSuccessMessage() {
	  if (this.if_exist_in_watchinglist){
		  this._success.next(`Removed from watchlist`); 
		  this.if_exist_in_watchinglist=false;
		  this.button_text='Add to Watchlist';
		  this.messageType='danger';
	//delete current media from watching list
	  let objArray;
	  
	  objArray=JSON.parse(localStorage.getItem('watching_list')||'[]');
	 let tmp_id=this.id; 
	  
	  objArray = objArray.filter(function(el) { return el.id != tmp_id; }); 
  
  
	  localStorage.setItem('watching_list', JSON.stringify(objArray));
		  

	  }
	  else{
		  
//add localStorage
	  let objArray;
	  if (localStorage.getItem('watching_list')!=null){
	  objArray=JSON.parse(localStorage.getItem('watching_list')||'[]');
	  let tmp_obj={};
	  tmp_obj['id']=this.id;
	  tmp_obj['media_type']='tv';
	  tmp_obj['name']=this.details.name;
	  tmp_obj['poster_path']=this.details.poster_path;
	  objArray.push(tmp_obj);
	  objArray=objArray.filter((v,i,a)=>a.findIndex(t=>(t.id === v.id))===i);
  }
  else{
	  objArray=[{id:this.id,media_type:'tv',name:this.details.name,poster_path:this.details.poster_path}];
  }
	  localStorage.setItem('watching_list', JSON.stringify(objArray));
  this._success.next(`Added to watchlist`); 
  this.button_text='Remove from Watchlist';
  this.if_exist_in_watchinglist=true;
  this.messageType='success';
	  }
  

  }
  open(content,id) {
    //get cast external
   this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/CastExternal?id="+id, {responseType: 'json'}).subscribe(data =>{
	this.cast_external=data[0];
	


  });
    //get cast details
   this.http.get<any>("https://changge-csci571-hw8-backend.wl.r.appspot.com/CastDetails?id="+id, {responseType: 'json'}).subscribe(data =>{
	this.cast_details=data[0];


	this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'});
  }); 
    
  }
  
  ClickCard(id,media_type,name,poster_path):void{
	  //add localStorage
	  let objArray;
	  if (localStorage.getItem('continue_movie')!=null){
	  objArray=JSON.parse(localStorage.getItem('continue_movie')||'[]');
	  let tmp_obj={};
	  tmp_obj['id']=id;
	  tmp_obj['media_type']=media_type;
	  tmp_obj['name']=name;
	  tmp_obj['poster_path']=poster_path;
	  objArray.push(tmp_obj);
	  objArray=objArray.filter((v,i,a)=>a.findIndex(t=>(t.id === v.id))===i);
  }
  else{
	  objArray=[{id:id,media_type:media_type,name:name,poster_path:poster_path}];
  }
	  localStorage.setItem('continue_movie', JSON.stringify(objArray));
	  
	  this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
		this.router.navigate(['/watch/'+media_type+'/'+id]));
		window.scrollTo(0, 0);
  }

}
